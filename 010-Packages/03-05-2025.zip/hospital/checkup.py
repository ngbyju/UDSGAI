def print_checkup():
    print("hello world, checkup")
def print_hello():
    print("hello world")

def print_calc():
    print("calculator")

class A:
    def __init__(self):
        self.a = "Hello"

    def calc(self):
        print("hello world")
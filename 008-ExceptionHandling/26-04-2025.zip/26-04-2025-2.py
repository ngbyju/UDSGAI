val = input("Enter values 0 to start and 1 to exit : ")

if val == "0":
    try :
        value1 = int(input("Enter a value : "))
    except:
        print("Error occured. Please try again with a different input")
elif val == "1":
    raise SystemExit("Closing the application.")




def add(value1):
    print(value1+2)

def add1(value1):
    print(value1+2)

def add2(value1):
    print(value1+2)

def add3(value1):
    print(value1+2)


add()
add1()
add2()
add3()
add()
add1()
add2()
add3()
add()
add1()
add2()
add3()
add()
add1()
add2()
add3()
add()
add1()
add2()
add3()
add()
add1()
add2()
add3()
    
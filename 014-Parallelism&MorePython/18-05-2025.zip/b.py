from a import *

print(__name__)
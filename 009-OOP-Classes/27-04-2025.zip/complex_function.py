class ComplexFunction():
    def check_even_or_odd(self,variable):
        if variable%2==0:
            print("Number is even")
        else:
            print("Number is odd")
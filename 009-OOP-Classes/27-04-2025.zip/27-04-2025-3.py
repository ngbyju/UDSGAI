class Calculator():
    def add(self,a,b):
        print(a+b)

    def subtract(self,a,b):
        print(a-b)

    def multiple(self,a,b):
        print(a*b)

    def divide(self,a,b):
        print(a/b)

class ComplexFunction():
    def check_even_or_odd(self,variable):
        if variable%2==0:
            print("Number is even")
        else:
            print("Number is odd")
        
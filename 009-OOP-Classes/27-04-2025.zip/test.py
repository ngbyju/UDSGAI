from maths import Calculator, add
# from maths import *
from complex_function import ComplexFunction

calc = Calculator()
cf = ComplexFunction()

calc.add(1,2)
calc.subtract(1,2)
calc.multiple(1,2)

cf.check_even_or_odd(12)
cf.check_even_or_odd(1)
cf.check_even_or_odd(100)
cf.check_even_or_odd(3)

add(1,2)


class Calculator():
    def add(self,a,b):
        print(a+b)

    def subtract(self,a,b):
        print(a-b)

    def multiple(self,a,b):
        print(a*b)

    def divide(self,a,b):
        print(a/b)

def add(a,b):
    print(a+b)
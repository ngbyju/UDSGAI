import maths

maths.add(1,2)

# ====================================

from maths import add

add(1,2)